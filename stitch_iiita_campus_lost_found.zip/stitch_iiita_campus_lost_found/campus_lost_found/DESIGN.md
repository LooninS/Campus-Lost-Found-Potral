---
name: Campus Lost & Found
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#444651'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#003120'
  on-tertiary: '#ffffff'
  tertiary-container: '#004a32'
  on-tertiary-container: '#4ac08f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes an academic yet vibrant and reassuring environment tailored for higher-education campuses. It combines corporate reliability with modern student-first accessibility. The primary emotional objective is to transform the anxiety of misplaced belongings into relief, trust, and swift community collaboration.

The visual style blends **Corporate Modern** with **Soft Tactile Minimalism**:
- Pristine, neutral, daylight surfaces that minimize cognitive fatigue.
- Structured, unambiguous visual indicators allowing rapid item scanning.
- Friendly, approachable radii and clear tactile hit areas designed for on-the-go mobile reporting between lecture halls and campus labs.
- Elevated academic authority through deep institution-grade indigos, accented by vibrant, purposeful status tokens and high-visibility verification badges.

## Colors

The palette is engineered for high-legibility communication in broad daylight across campus:

- **Primary Canvas & Surfaces**: The base canvas is `#F8FAFC` (Slate 50), paired with crisp pure white `#FFFFFF` for content cards and modular containers. Subtle boundary separation is governed by `#E2E8F0` (Slate 200).
- **Brand & Structural Navigation**: 
  - Primary: `#1E3A8A` (Deep Campus Indigo) anchors navigation bars, primary headers, and institutional verification markers.
  - Secondary / Interactive: `#2563EB` (Electric Blue) commands interactive primary actions, link states, and focus triggers.
- **Status & Lifecycle Semantics**:
  - *Lost*: Background `#FFF1F2` (Rose 50), Border `#FECDD3` (Rose 200), Text `#BE123C` (Rose 700). High urgency without inducing panic.
  - *Found*: Background `#ECFDF5` (Emerald 50), Border `#A7F3D0` (Emerald 200), Text `#047857` (Emerald 700). Evokes discovery, safety, and positive resolution.
  - *Claimed / Resolved*: Background `#F0F9FF` (Sky 50), Border `#BAE6FD` (Sky 200), Text `#0369A1` (Sky 700). Communicates a closed audit loop.
  - *Pending / Moderation*: Background `#FFFBEB` (Amber 50), Border `#FDE68A` (Amber 200), Text `#B45309` (Amber 700).
- **Campus Intelligence & AI Integration**:
  - Sarvam AI & Automated Match Badge: Background `#EEF2FF` (Indigo 50), Border `#C7D2FE` (Indigo 200), Accent `#4338CA` (Indigo 700) with a subtle dual-tone sparkle accent in `#818CF8`.
- **Text & Contrast Ratios**:
  - Headings & Primary Labels: `#0F172A` (Slate 900) achieving WCAG AAA contrast against white cards.
  - Body & Form Text: `#334155` (Slate 700).
  - Supporting & Metadata: `#64748B` (Slate 500).

## Typography

The type system blends the human-friendly, optimistic geometric forms of **Plus Jakarta Sans** for primary reading and headlines with the ultra-meticulous, screen-tuned precision of **Inter** for compact metadata, timestamps, location tags, and system chips.

- **Headlines & Expressive Titles**: Rendered in Plus Jakarta Sans with subtle negative tracking (`-0.01em` to `-0.02em`) to keep longer item titles (e.g., "Space Grey M2 MacBook Air near CC-3 Lab 2") punchy and readable without wrapping awkwardly.
- **Reading Body**: Set at a comfortable base of 14px to 16px with open vertical line height to facilitate effortless scanning on smaller mobile screens.
- **Micro-labels and Badges**: Inter in medium and semi-bold weights guarantees clean letter separation and zero optical smearing, essential for identifiers like student roll numbers, timestamps, and status chips.

## Layout & Spacing

This design system uses an adaptive grid model built to support heavy catalog browsing, live photo matching, and multi-step item registration flows.

- **Desktop (1024px and up)**:
  - Standard 12-column layout with a maximum container width of `1280px`.
  - Column gutters set to `1.5rem` (`24px`), outer canvas margin set to `2rem` (`32px`).
  - Supports a persistent Left Navigation / Filter Drawer (3 columns) and an expansive Item Feed (9 columns).
- **Tablet (768px – 1023px)**:
  - 8-column layout with fluid margins of `1.5rem` (`24px`). Item cards organize into comfortable 2-column or 3-column matrices.
- **Mobile (Below 768px)**:
  - 4-column layout with `1rem` (`16px`) horizontal margins and gutters. Single-column stacked cards ensure maximum visual preview space for item photos.
  - Floating action buttons and mobile bottom navigation dock with safe-area insets (`padding-bottom: env(safe-area-inset-bottom)`).
- **Rhythm Rules**:
  - Inner card padding strictly adheres to `space-md` (`1rem`) on compact views and `space-lg` (`1.5rem`) on detailed item views.
  - Inter-component vertical rhythm strictly steps across `space-sm` (`8px`) for tight label-to-input pairings and `space-xl` (`40px`) between discrete screen sections.

## Elevation & Depth

To preserve an airy, modern, and trustworthy atmosphere, elevation relies on **ambient micro-shadows paired with low-contrast structural outlines** rather than heavy drop shadows:

- **Level 0 (Flat Surface / Background Canvas)**: `#F8FAFC` base surface with no shadow.
- **Level 1 (Cards, Floating Lists, Input Panels)**:
  - Background: `#FFFFFF`
  - Outline: `1px solid #E2E8F0`
  - Shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`
- **Level 2 (Hover States, Interactive Cards, Filter Menus)**:
  - Background: `#FFFFFF`
  - Outline: `1px solid #CBD5E1`
  - Shadow: `0 8px 20px -4px rgba(30, 58, 138, 0.08), 0 4px 6px -2px rgba(15, 23, 42, 0.03)`
  - A subtle 1px translate-Y shift (`transform: translateY(-2px)`) gives items an immediate responsive feel.
- **Level 3 (Modals, Match Drawers, Floating Bottom Sheets)**:
  - Background: `#FFFFFF`
  - Outline: `1px solid rgba(226, 232, 240, 0.8)`
  - Shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.05)`
  - Backdropped with a soft ambient blur (`backdrop-filter: blur(6px)` over `rgba(15, 23, 42, 0.4)`).

## Shapes

The shape geometry utilizes **Level 2 (Rounded)** with purposeful scaling to convey friendliness and tactility:

- **Interactive Core (Buttons, Inputs, Selectors)**: `0.5rem` (`8px`) to `0.75rem` (`12px`) corner radius. Fits finger pads smoothly while preserving architectural order.
- **Card Containers & Item Tiles**: Standardized on `rounded-2xl` (`1rem` / `16px`) for standard cards and `1.25rem` (`20px`) for hero spotlight cards.
- **Micro Chips & Badges**: Fully pill-shaped (`9999px` radius) to instantly differentiate interactive tags, status indicators, and category tokens from rectangular inputs.
- **Image Previews**: Nested radii formula applied—image containers adopt `rounded-xl` (`12px`) within `rounded-2xl` (`16px`) parent containers, preserving a uniform inner margin border.

## Components

### Buttons
- **Primary**: Solid `#1E3A8A` background, pure white text, font weight 600, `h-11` (44px) default desktop height, `h-12` (48px) mobile touch target. Rounded to `0.75rem` (`12px`). Hover state transitions smoothly to `#2563EB`.
- **Secondary / Ghost**: White background, `1px solid #E2E8F0`, `#1E3A8A` text. Hover state triggers `#F8FAFC` background with `#CBD5E1` border.
- **Destructive**: Rose background `#FFF1F2`, text `#BE123C`, `1px solid #FECDD3`. Hover transitions to `#FEE2E2`.

### Status Badges & Chips
- Built with pill-radii (`rounded-full`), `px-3 py-1`, tracking `0.02em`, font size `12px` (Inter semi-bold).
- **Lost Badge**: `#FFF1F2` background, `#BE123C` text, paired with a solid `#E11D48` 6px pulse dot.
- **Found Badge**: `#ECFDF5` background, `#047857` text, paired with a solid `#10B981` 6px indicator dot.
- **Claimed Badge**: `#F0F9FF` background, `#0369A1` text, paired with an inline check icon.
- **Sarvam AI Verification Badge**: Deep indigo tint `#EEF2FF`, text `#4338CA`, `1px solid #C7D2FE`. Prefixed with an AI sparkle icon, used to denote automated visual matches or translation into local campus dialects.

### Item Listing Cards
- Built with Level 1 elevation, `p-4` internal padding, `rounded-2xl` borders, and white surfaces.
- Contains an aspect-ratio `4:3` image preview window at top with an overlay badge for status at top-left and timestamp at top-right.
- Item title rendered in `headline-sm`, followed by a dual-line metadata row: Location icon with campus venue (e.g., "Library 2nd Floor", "Admin Block") and Roll/User avatar badge.
- Interactive hover triggers Level 2 elevation and a slight accent border tint of `#93C5FD`.

### Input Fields & Search Bars
- Base height `46px`, `rounded-xl`, background `#FFFFFF`, border `1px solid #CBD5E1`.
- Placeholder text in `#94A3B8`.
- Focus state: Border transitions to `#2563EB` with an ambient glow (`box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15)`), outline none.
- Search input includes an integrated quick-clear action button and keyboard shortcut indicator (`Cmd+K` or `/`).

### Checkboxes & Radio Controls
- Checkbox: `20px x 20px`, `rounded-md` (6px radius), `1.5px solid #CBD5E1`. Active state fills `#2563EB` with a crisp white tick mark.
- Radio: Circular with an inner dot diameter of 8px when selected.

### Lists & Activity Feeds
- Divided with hair-thin borders (`1px solid #F1F5F9`).
- Active items use a subtle `#F8FAFC` background on hover with smooth transition timings of `150ms ease-in-out`.
- Empty states feature clean, dual-tone line illustrations paired with reassuring copy and a prominent primary action ("Report an Item").